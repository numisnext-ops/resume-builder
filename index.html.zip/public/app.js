const $ = (s) => document.querySelector(s);
const notice = $("#notice");
let currentUser = null;
function say(message, kind="ok") {
  notice.textContent = message; notice.className = `notice show ${kind}`;
  notice.scrollIntoView({behavior:"smooth", block:"nearest"});
}
async function api(url, options={}) {
  const res = await fetch(url, { credentials:"same-origin", ...options,
    headers: { ...(options.body ? {"Content-Type":"application/json"} : {}), ...(options.headers||{}) } });
  const data = res.status === 204 ? {} : await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.error || "Request failed.");
  return data;
}
function formObj(form) { return Object.fromEntries(new FormData(form).entries()); }
function lines(v) { return String(v||"").split(/\n/).map(x=>x.trim()).filter(Boolean); }
function csv(v) { return String(v||"").split(",").map(x=>x.trim()).filter(Boolean); }
function showText(id, text, fallback) { $(id).textContent = text || fallback; }
const months=["January","February","March","April","May","June","July","August","September","October","November","December"];
const years=Array.from({length:77},(_,i)=>String(new Date().getFullYear()-i));
const jobTypes=["Full-time","Part-time","Internship","Contract","Freelance","Temporary","Apprenticeship","Other"];
const levels=["10th / Secondary","12th / Higher Secondary","Diploma","Bachelor's Degree","Master's Degree","Doctorate / PhD","Professional Qualification","Other"];
function selectOptions(items,placeholder){return `<option value="">${placeholder}</option>`+items.map(x=>`<option>${x}</option>`).join("");}
function inputField(label,name,placeholder=""){return `<label>${label}<input name="${name}" placeholder="${placeholder}" maxlength="200"></label>`;}
function selectField(label,name,items,placeholder){return `<label>${label}<select name="${name}">${selectOptions(items,placeholder)}</select></label>`;}
function textField(label,name,placeholder=""){return `<label class="wide">${label}<textarea name="${name}" rows="2" placeholder="${placeholder}"></textarea></label>`;}
function addRepeat(containerId,title,markup){const box=document.createElement("div");box.className="repeat-card";box.innerHTML=`<div class="repeat-card-head"><strong>${title} ${$("#"+containerId).children.length+1}</strong><button type="button" class="secondary compact remove-repeat">Remove</button></div><div class="repeat-fields">${markup}</div>`;$("#"+containerId).append(box);box.querySelector(".remove-repeat").addEventListener("click",()=>{box.remove();renumberRepeats(containerId,title);renderPreview();});box.addEventListener("input",renderPreview);box.addEventListener("change",renderPreview);renderPreview();return box;}
function renumberRepeats(id,title){[...$("#"+id).children].forEach((el,i)=>el.querySelector("strong").textContent=`${title} ${i+1}`);}
function addExperience(){const c=addRepeat("experienceList","Experience",inputField("Job title *","role","e.g. Sales Executive")+inputField("Company *","company","Company name")+selectField("Job type *","jobType",jobTypes,"Select job type")+inputField("If Other, specify","jobTypeOther")+inputField("Location","workLocation","City / remote")+selectField("From month *","fromMonth",months,"Select month")+selectField("From year *","fromYear",years,"Select year")+selectField("Currently work here?","current",["Yes","No"],"Select")+selectField("To month","toMonth",[...months,"Present"],"Select month")+selectField("To year","toYear",[...years,"Present"],"Select year")+textField("Description / achievements *","description","Key responsibilities and achievements"));const current=c.querySelector('[name="current"]');current.addEventListener("change",()=>{const isCurrent=current.value==="Yes";const m=c.querySelector('[name="toMonth"]'),y=c.querySelector('[name="toYear"]');if(isCurrent){m.value="Present";y.value="Present";m.disabled=true;y.disabled=true;}else{m.disabled=false;y.disabled=false;if(m.value==="Present")m.value="";if(y.value==="Present")y.value="";}renderPreview();});}
function addEducation(){addRepeat("educationList","Education",selectField("Level of education *","level",levels,"Select level")+inputField("If Other, specify","levelOther")+inputField("Qualification / degree name","degreeName","e.g. B.Com, MBA")+inputField("Field of study / specialisation","specialisation")+inputField("School / university / institution *","institution")+inputField("Country","studyCountry","Country")+selectField("Completion month","completionMonth",months,"Select month")+selectField("Completion year","completionYear",years,"Select year")+inputField("Grade / percentage","grade","e.g. 82%")+textField("Additional details","educationDetails","Relevant coursework, honours, etc."));}
function addQualification(){addRepeat("qualificationList","Qualification",inputField("Name of qualification / certification / licence *","qualificationName")+inputField("Issuing organisation","issuer")+selectField("Issue month","issueMonth",months,"Select month")+selectField("Issue year","issueYear",years,"Select year")+inputField("Credential ID (optional)","credentialId")+inputField("Expiry date (optional)","expiryDate","e.g. 2030 or Not applicable")+textField("Description","qualificationDescription","Details or skills covered"));}
function readRepeats(id){return [...$("#"+id).children].map(card=>{const o={};card.querySelectorAll("input,select,textarea").forEach(el=>o[el.name]=el.value.trim());return o;});}
function fillEntries(id,items,mapper,fallback){const el=$(id);el.replaceChildren();let n=0;items.forEach(item=>{const [title,meta,desc]=mapper(item);if(!title&&!meta&&!desc)return;const wrap=document.createElement("div");wrap.className="preview-item";if(title){const b=document.createElement("strong");b.textContent=title;wrap.append(b);}if(meta){const m=document.createElement("p");m.textContent=meta;wrap.append(m);}if(desc){const d=document.createElement("p");d.textContent=desc;wrap.append(d);}el.append(wrap);n++;});if(!n)el.textContent=fallback;}
function renderPreview() {
  const f=$("#profileForm"), d=formObj(f);
  showText("#pName", $("#fullName").value.trim(), "Your Name");showText("#pHeadline", d.headline, "Your target job title");
  showText("#pContact", [$("#resumeEmail").value,d.phone,d.city].filter(Boolean).join(" · "), "Email · Phone · City");showText("#pSummary",d.summary,"Your professional summary will appear here.");
  const exp=readRepeats("experienceList");fillEntries("#pExperience",exp,x=>[x.role,[x.company,x.jobType==="Other"?x.jobTypeOther:x.jobType,x.workLocation].filter(Boolean).join(" · "),[[x.fromMonth,x.fromYear].filter(Boolean).join(" "),x.current==="Yes"?"Present":[x.toMonth,x.toYear].filter(Boolean).join(" "),x.description].filter(Boolean).join(" — ")],"Add your experience details.");
  const edu=readRepeats("educationList");fillEntries("#pEducation",edu,x=>[x.degreeName||(x.level==="Other"?x.levelOther:x.level),[x.specialisation,x.institution,x.studyCountry,[x.completionMonth,x.completionYear].filter(Boolean).join(" "),x.grade].filter(Boolean).join(" · "),x.educationDetails],"Add your education details.");
  showText("#pSkills",d.skills,"Add your skills.");
  fillEntries("#pProjects",lines(d.projects).map(text=>({text})),x=>[x.text,"",""],"Optional projects.");
  const quals=readRepeats("qualificationList");fillEntries("#pQualifications",quals,x=>[x.qualificationName,[x.issuer,[x.issueMonth,x.issueYear].filter(Boolean).join(" "),x.expiryDate?"Expiry: "+x.expiryDate:""].filter(Boolean).join(" · "),x.qualificationDescription],"Add qualifications or certifications.");
  showText("#pLanguages",d.languages,"Add languages you speak.");
}
$("#addExperience").addEventListener("click",addExperience);$("#addEducation").addEventListener("click",addEducation);$("#addQualification").addEventListener("click",addQualification);
$("#profileForm").addEventListener("input", renderPreview);
$("#profileForm").addEventListener("submit", async e=>{
  e.preventDefault();
  if(!currentUser || currentUser.role!=="candidate"){say("Create an account or log in as a candidate before saving your profile.","err");return;}
  const f=formObj(e.currentTarget);
  const payload={
    headline:f.headline,phone:f.phone,city:f.city,summary:f.summary,
    education:readRepeats("educationList"),experience:readRepeats("experienceList"),
    skills:csv(f.skills),projects:structured(lines(f.projects)),certifications:readRepeats("qualificationList"),
    languages:csv(f.languages),visible_to_employers:e.currentTarget.elements.visible_to_employers.checked
  };
  try{await api("/api/profile",{method:"PUT",body:JSON.stringify(payload)});say("Profile saved securely to the job portal database.");}
  catch(err){say(err.message,"err");}
});
function populateProfile(p){
  const f=$("#profileForm");f.elements.headline.value=p.headline||"";f.elements.phone.value=p.phone||"";f.elements.city.value=p.city||"";f.elements.summary.value=p.summary||"";
  f.elements.skills.value=(p.skills||[]).join(", ");f.elements.projects.value=(p.projects||[]).map(x=>typeof x==="string"?x:(x.text||Object.values(x).join(" | "))).join("\n");f.elements.languages.value=(p.languages||[]).join(", ");f.elements.visible_to_employers.checked=!!p.visible_to_employers;
  [["experienceList","addExperience",p.experience||[]],["educationList","addEducation",p.education||[]],["qualificationList","addQualification",p.certifications||[]]].forEach(([id,buttonId,rows])=>{const root=$("#"+id);root.replaceChildren();(Array.isArray(rows)&&rows.length?rows:[{}]).forEach(row=>{ $("#"+buttonId).click();const card=root.lastElementChild;Object.entries(row||{}).forEach(([key,value])=>{const el=card.querySelector(`[name="${CSS.escape(key)}"]`);if(el)el.value=typeof value==="string"?value:(value??"");});const current=card.querySelector('[name="current"]');if(current&&current.value==="Yes"){current.dispatchEvent(new Event("change"));}});});renderPreview();
}
$("#loadProfile").addEventListener("click",async()=>{
  if(!currentUser||currentUser.role!=="candidate"){say("Log in as a candidate to load your saved profile.","err");return;}
  try{const d=await api("/api/profile");populateProfile(d.profile||{});say("Saved profile loaded.");}catch(e){say(e.message,"err");}
});
$("#printResume").addEventListener("click",()=>{renderPreview();window.print();});
async function authSubmit(e, endpoint){
  e.preventDefault();
  try{
    const d=await api(endpoint,{method:"POST",body:JSON.stringify(formObj(e.currentTarget))});
    currentUser=d.user; await refreshUser(); say(endpoint.includes("register")?"Account created. Complete your resume and save it.":"You are logged in.");
    e.currentTarget.reset();
  }catch(err){say(err.message,"err");}
}
$("#registerForm").addEventListener("submit",e=>authSubmit(e,"/api/auth/register"));
$("#loginForm").addEventListener("submit",e=>authSubmit(e,"/api/auth/login"));
async function refreshUser(){
  const d=await api("/api/me");currentUser=d.user;
  $("#authForms").hidden=!!currentUser;$("#signedIn").hidden=!currentUser;
  if(currentUser){
    $("#signedIn").replaceChildren();
    const p=document.createElement("p");p.textContent=`Signed in as ${currentUser.name} (${currentUser.role}).`;$("#signedIn").append(p);
    const b=document.createElement("button");b.className="secondary";b.textContent="Log out";b.addEventListener("click",async()=>{try{await api("/api/auth/logout",{method:"POST"});currentUser=null;await refreshUser();say("You have logged out.");}catch(e){say(e.message,"err");}});$("#signedIn").append(b);
  }
  $("#employerTools").hidden=!(currentUser&&(currentUser.role==="employer"||currentUser.role==="admin"));
  $("#resumeEmail").value=currentUser?.email||"";
  if(currentUser?.role==="candidate"){$("#fullName").value=currentUser.name;try{const p=await api("/api/profile");populateProfile(p.profile||{});}catch{}}
  renderPreview();
}
async function loadJobs(keyword=""){
  const results=$("#jobResults");results.textContent="Loading jobs…";
  try{const d=await api("/api/jobs?keyword="+encodeURIComponent(keyword));results.replaceChildren();
    if(!d.jobs.length){results.textContent="No jobs found yet. Please check back soon.";return;}
    d.jobs.forEach(j=>{const card=document.createElement("article");card.className="job-card";const h=document.createElement("h3");h.textContent=j.title;const meta=document.createElement("p");meta.className="job-meta";meta.textContent=[j.company_name,j.location,j.employment_type].filter(Boolean).join(" · ");const desc=document.createElement("p");desc.textContent=j.description;card.append(h,meta,desc);results.append(card);});
  }catch(e){results.textContent=e.message;}
}
$("#jobSearch").addEventListener("submit",e=>{e.preventDefault();loadJobs(formObj(e.currentTarget).keyword||"");});
$("#jobForm").addEventListener("submit",async e=>{
  e.preventDefault();const b=formObj(e.currentTarget);b.skills=csv(b.skills);
  try{await api("/api/jobs",{method:"POST",body:JSON.stringify(b)});e.currentTarget.reset();say("Job published.");loadJobs();}catch(err){say(err.message,"err");}
});
$("#candidateSearch").addEventListener("submit",async e=>{
  e.preventDefault();const out=$("#candidateResults");out.textContent="Searching…";
  try{const d=await api("/api/candidates?keyword="+encodeURIComponent(formObj(e.currentTarget).keyword||""));out.replaceChildren();
    if(!d.candidates.length){out.textContent="No visible candidate profiles matched your search.";return;}
    d.candidates.forEach(c=>{const card=document.createElement("article");card.className="job-card";const h=document.createElement("h3");h.textContent=c.name;const meta=document.createElement("p");meta.className="job-meta";meta.textContent=[c.headline,c.city].filter(Boolean).join(" · ");const summary=document.createElement("p");summary.textContent=c.summary||"No summary provided.";const skills=document.createElement("p");skills.textContent="Skills: "+(c.skills||[]).join(", ");card.append(h,meta,summary,skills);out.append(card);});
  }catch(err){out.textContent=err.message;}
});
async function init(){if(!$("#experienceList").children.length)addExperience();if(!$("#educationList").children.length)addEducation();if(!$("#qualificationList").children.length)addQualification();renderPreview();await loadJobs();try{await refreshUser();}catch(e){say("Could not connect to the server. Check that the app and database are running.","err");}}
init();
