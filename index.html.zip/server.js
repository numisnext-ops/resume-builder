require("dotenv").config();
const express = require("express");
const session = require("express-session");
const PgSession = require("connect-pg-simple")(session);
const { Pool } = require("pg");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");

if (!process.env.DATABASE_URL || !process.env.SESSION_SECRET) {
  console.error("Set DATABASE_URL and SESSION_SECRET in .env");
  process.exit(1);
}

const app = express();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: true } : false
});

app.disable("x-powered-by");
app.use(helmet());
app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: true, legacyHeaders: false }));
app.use(session({
  store: new PgSession({ pool, tableName: "user_sessions", createTableIfMissing: true }),
  name: "jobportal.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 8
  }
}));

app.use(express.static(path.join(__dirname, "public")));

const clean = (v, max = 5000) => typeof v === "string" ? v.trim().slice(0, max) : "";
const emailOk = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) && v.length <= 254;
const safeArray = (v, max = 30) => Array.isArray(v) ? v.slice(0, max).map(x => {
  if (typeof x === "string") return x.trim().slice(0, 500);
  if (x && typeof x === "object" && !Array.isArray(x)) {
    const out = {};
    for (const [k, val] of Object.entries(x).slice(0, 12)) {
      if (typeof val === "string" || typeof val === "number" || typeof val === "boolean") out[String(k).slice(0, 40)] = String(val).slice(0, 500);
    }
    return out;
  }
  return null;
}).filter(Boolean) : [];

function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "Please log in first." });
  next();
}
function requireRole(role) {
  return (req, res, next) => {
    if (!req.session.user) return res.status(401).json({ error: "Please log in first." });
    if (req.session.user.role !== role && req.session.user.role !== "admin") {
      return res.status(403).json({ error: "You do not have permission to do that." });
    }
    next();
  };
}

app.post("/api/auth/register", async (req, res, next) => {
  try {
    const name = clean(req.body.name, 120);
    const email = clean(req.body.email, 254).toLowerCase();
    const password = typeof req.body.password === "string" ? req.body.password : "";
    const role = req.body.role;
    if (name.length < 2 || !emailOk(email) || password.length < 10 || password.length > 200 || !["candidate", "employer"].includes(role)) {
      return res.status(400).json({ error: "Enter a valid name and email, choose a role, and use a password of at least 10 characters." });
    }
    const password_hash = await bcrypt.hash(password, 12);
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      const u = await client.query(
        "INSERT INTO users(name,email,password_hash,role) VALUES($1,$2,$3,$4) RETURNING id,name,email,role",
        [name, email, password_hash, role]
      );
      if (role === "candidate") {
        await client.query("INSERT INTO candidate_profiles(user_id) VALUES($1)", [u.rows[0].id]);
      } else {
        await client.query("INSERT INTO employer_profiles(user_id) VALUES($1)", [u.rows[0].id]);
      }
      await client.query("COMMIT");
      req.session.regenerate(err => {
        if (err) return next(err);
        req.session.user = u.rows[0];
        req.session.save(err2 => err2 ? next(err2) : res.status(201).json({ user: req.session.user }));
      });
    } catch (e) {
      await client.query("ROLLBACK");
      if (e.code === "23505") return res.status(409).json({ error: "An account with that email already exists." });
      throw e;
    } finally { client.release(); }
  } catch (e) { next(e); }
});

app.post("/api/auth/login", async (req, res, next) => {
  try {
    const email = clean(req.body.email, 254).toLowerCase();
    const password = typeof req.body.password === "string" ? req.body.password : "";
    const result = await pool.query("SELECT id,name,email,password_hash,role FROM users WHERE email=$1", [email]);
    const user = result.rows[0];
    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: "Email or password is incorrect." });
    }
    const publicUser = { id: user.id, name: user.name, email: user.email, role: user.role };
    req.session.regenerate(err => {
      if (err) return next(err);
      req.session.user = publicUser;
      req.session.save(err2 => err2 ? next(err2) : res.json({ user: publicUser }));
    });
  } catch (e) { next(e); }
});

app.post("/api/auth/logout", (req, res, next) => {
  req.session.destroy(err => {
    if (err) return next(err);
    res.clearCookie("jobportal.sid", { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production" });
    res.json({ ok: true });
  });
});

app.get("/api/me", (req, res) => res.json({ user: req.session.user || null }));

app.get("/api/profile", requireRole("candidate"), async (req, res, next) => {
  try {
    const r = await pool.query(
      "SELECT headline,phone,city,summary,education,experience,skills,projects,certifications,languages,visible_to_employers FROM candidate_profiles WHERE user_id=$1",
      [req.session.user.id]
    );
    res.json({ profile: r.rows[0] || null });
  } catch (e) { next(e); }
});

app.put("/api/profile", requireRole("candidate"), async (req, res, next) => {
  try {
    const b = req.body || {};
    const visible = b.visible_to_employers === true;
    const r = await pool.query(
      `UPDATE candidate_profiles SET headline=$1, phone=$2, city=$3, summary=$4,
       education=$5::jsonb, experience=$6::jsonb, skills=$7::jsonb, projects=$8::jsonb,
       certifications=$9::jsonb, languages=$10::jsonb, visible_to_employers=$11, updated_at=NOW()
       WHERE user_id=$12 RETURNING headline,phone,city,summary,education,experience,skills,projects,certifications,languages,visible_to_employers`,
      [
        clean(b.headline,160), clean(b.phone,40), clean(b.city,100), clean(b.summary,3000),
        JSON.stringify(safeArray(b.education)), JSON.stringify(safeArray(b.experience)),
        JSON.stringify(safeArray(b.skills).map(x => typeof x === "string" ? x : JSON.stringify(x))),
        JSON.stringify(safeArray(b.projects)), JSON.stringify(safeArray(b.certifications)),
        JSON.stringify(safeArray(b.languages).map(x => typeof x === "string" ? x : JSON.stringify(x))),
        visible, req.session.user.id
      ]
    );
    res.json({ profile: r.rows[0] });
  } catch (e) { next(e); }
});

app.get("/api/jobs", async (req, res, next) => {
  try {
    const keyword = clean(req.query.keyword, 100);
    const r = await pool.query(
      `SELECT j.id,j.title,j.company_name,j.location,j.employment_type,j.description,j.skills,j.created_at
       FROM jobs j WHERE j.is_active=TRUE
       AND ($1='' OR j.title ILIKE '%' || $1 || '%' OR j.company_name ILIKE '%' || $1 || '%' OR j.location ILIKE '%' || $1 || '%')
       ORDER BY j.created_at DESC LIMIT 100`, [keyword]
    );
    res.json({ jobs: r.rows });
  } catch (e) { next(e); }
});

app.post("/api/jobs", requireRole("employer"), async (req, res, next) => {
  try {
    const b = req.body || {};
    const title = clean(b.title, 180), company = clean(b.company_name, 180), description = clean(b.description, 10000);
    if (title.length < 2 || company.length < 2 || description.length < 20) {
      return res.status(400).json({ error: "Add a job title, company name and a description of at least 20 characters." });
    }
    const r = await pool.query(
      `INSERT INTO jobs(employer_id,title,company_name,location,employment_type,description,skills)
       VALUES($1,$2,$3,$4,$5,$6,$7::jsonb)
       RETURNING id,title,company_name,location,employment_type,description,skills,created_at`,
      [req.session.user.id, title, company, clean(b.location,160), clean(b.employment_type,50) || "Full-time", description,
       JSON.stringify(safeArray(b.skills).map(x => typeof x === "string" ? x : JSON.stringify(x)))]
    );
    res.status(201).json({ job: r.rows[0] });
  } catch (e) { next(e); }
});

app.get("/api/candidates", requireRole("employer"), async (req, res, next) => {
  try {
    const keyword = clean(req.query.keyword, 100);
    const r = await pool.query(
      `SELECT u.id,u.name,p.headline,p.city,p.summary,p.skills,p.education,p.experience
       FROM users u JOIN candidate_profiles p ON p.user_id=u.id
       WHERE u.role='candidate' AND p.visible_to_employers=TRUE
       AND ($1='' OR u.name ILIKE '%' || $1 || '%' OR p.headline ILIKE '%' || $1 || '%' OR p.city ILIKE '%' || $1 || '%' OR p.summary ILIKE '%' || $1 || '%')
       ORDER BY p.updated_at DESC LIMIT 100`, [keyword]
    );
    res.json({ candidates: r.rows });
  } catch (e) { next(e); }
});

app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: "Something went wrong. Please try again." });
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Job portal running at http://localhost:${port}`));
