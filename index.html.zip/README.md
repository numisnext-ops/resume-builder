# Job Portal Starter — Candidates + Employers

A starter full-stack project using:
- HTML/CSS/vanilla JavaScript
- Node.js + Express
- PostgreSQL
- Server-side sessions stored in PostgreSQL
- Role-based access: `candidate`, `employer`, `admin`

## Requirements
- Node.js 20+
- PostgreSQL 15+
- A database created for this project

## Setup
1. Extract this folder.
2. Create a PostgreSQL database, for example `job_portal`.
3. Copy `.env.example` to `.env` and set `DATABASE_URL` and a long random `SESSION_SECRET`.
4. In the project folder, run:

   ```bash
   npm install
   psql "$DATABASE_URL" -f schema.sql
   npm run dev
   ```

5. Open http://localhost:3000

If `psql` is not available, run `schema.sql` using your PostgreSQL administration tool.

## What works in this starter
- Candidate and employer registration
- Login/logout with server-side sessions
- Candidate profile create/update
- Employer can create a job listing
- Public job listing
- Employer-only candidate search for candidates who have opted into employer visibility
- Basic validation, Helmet security headers, rate limiting, parameterized SQL queries
- Resume builder page with live preview and browser print/save-to-PDF

## Important limitations before public launch
This is a development starter, not a production-audited service. Before launch:
- Use HTTPS and a secure production session configuration.
- Configure trusted proxy settings only for your actual hosting environment.
- Add email verification, password reset, CSRF protection appropriate to your deployment, audit logging, backups, monitoring and abuse reporting.
- Review India DPDP Act and applicable rules / privacy obligations with qualified counsel.
- Collect only necessary candidate data, show a clear privacy notice, and get consent before making profiles searchable.
- Do not store Aadhaar, passwords in plaintext, or other unnecessary sensitive information.
- Add employer/company verification and moderation before allowing real hiring activity.
- Add upload validation and private object storage before accepting resume files/photos.
- Set a strong `SESSION_SECRET`; never commit `.env` to source control.

## Main endpoints
- `POST /api/auth/register` — `{name,email,password,role}` (`role` is `candidate` or `employer`)
- `POST /api/auth/login` — `{email,password}`
- `POST /api/auth/logout`
- `GET /api/me`
- `GET /api/profile`
- `PUT /api/profile` — candidate only
- `GET /api/jobs`
- `POST /api/jobs` — employer only
- `GET /api/candidates?keyword=...` — employer only; only visible candidates

## Data flow
Browser → Express API → PostgreSQL. The database connection string and password hashes stay on the server; never put database credentials in browser JavaScript.
